package com.example.czcionki;

import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private String[] cytaty = {"Dzień dobry", "Good morning", "Buenos dias"};
    private int numerCytatu = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView napisRozmiar = findViewById(R.id.napisRozmiar);
        SeekBar suwakRozmiaru = findViewById(R.id.suwakRozmiaru);
        TextView napisCytat = findViewById(R.id.napisCytat);
        Button przyciskZmianaCytatu = findViewById(R.id.przyciskZmianaCytatu);

        suwakRozmiaru.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                napisRozmiar.setText("Rozmiar: " + progress);
                if (progress > 0) {
                    napisCytat.setTextSize(TypedValue.COMPLEX_UNIT_SP, progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        przyciskZmianaCytatu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                numerCytatu = numerCytatu + 1;
                if (numerCytatu == cytaty.length) {
                    numerCytatu = 0;
                }
                napisCytat.setText(cytaty[numerCytatu]);
            }
        });
    }
}