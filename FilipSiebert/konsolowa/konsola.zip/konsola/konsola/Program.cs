﻿using System;

class Program
{
    internal static void SortujBabelkowo(int[] tablica)
    {
        for (int i = 0; i < tablica.Length - 1; i++)
        {
            for (int j = 0; j < tablica.Length - 1 - i; j++)
            {
                if (tablica[j] > tablica[j + 1])
                {
                    int pomocnicza = tablica[j];
                    tablica[j] = tablica[j + 1];
                    tablica[j + 1] = pomocnicza;
                }
            }
        }
    }

    static void Main()
    {
        Random generator = new Random();
        int[] liczby = new int[100];

        for (int i = 0; i < liczby.Length; i++)
        {
            liczby[i] = generator.Next(0, 1001);
        }

        SortujBabelkowo(liczby);

        Console.WriteLine("Posortowana tablica (rosnaco):");
        for (int i = 0; i < liczby.Length; i++)
        {
            Console.Write(liczby[i] + "; ");
        }
        Console.WriteLine();
        Console.WriteLine();

        TestSortowania.Uruchom();

        Console.ReadKey();
    }
}